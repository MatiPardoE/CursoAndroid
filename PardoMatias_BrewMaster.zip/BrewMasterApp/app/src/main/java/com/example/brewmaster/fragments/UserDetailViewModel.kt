package com.example.brewmaster.fragments

import androidx.lifecycle.ViewModel

class UserDetailViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}