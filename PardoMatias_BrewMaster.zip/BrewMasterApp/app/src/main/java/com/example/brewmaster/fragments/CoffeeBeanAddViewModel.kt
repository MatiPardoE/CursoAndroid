package com.example.brewmaster.fragments

import androidx.lifecycle.ViewModel

class CoffeeBeanAddViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}